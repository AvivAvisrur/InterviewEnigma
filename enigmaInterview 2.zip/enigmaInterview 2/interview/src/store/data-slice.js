import { createSlice } from "@reduxjs/toolkit";


const dataSlice = createSlice(
    {
        name:"dummyData",
        initialState:{
            data:[]
        },
        reducers:{
            updateData(state,action){
                state.data = action.payload
            }
        }
    }
);

export const dataActions = dataSlice.actions; 
export default dataSlice;