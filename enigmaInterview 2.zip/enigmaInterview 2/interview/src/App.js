import './App.css';
import {useSelector} from "react-redux"
import Dummydata, { dummyData } from './Components/dummyData';
import store from './store/store';
import { dataActions } from './store/data-slice';
import * as React from 'react';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListSubheader from '@mui/material/ListSubheader';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Layout from './Components/Layout';




function App() {
  store.dispatch(dataActions.updateData(dummyData));
  const data = useSelector(state => state.data.data)
  console.log(data)
  return (
    <>
      <Layout/>
    </>
  )
}

export default App;
