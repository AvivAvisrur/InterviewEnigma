import dataSlice, { dataActions } from "../store/data-slice"
import store from "../store/store"
import {useDispatch} from "react-redux";
import iconXrp from "../icons/iconXRP.png"
import BitcoinIcon from "../icons/BitcoinIcon.png"
import LtcIcon from "../icons/LtcIcon.png"


export const dummyData = [
    {
        title:"XRP",
        img:iconXrp,
        insideData:[
            {
                title:"XRPaud",
                currency:1.55,
                precentage:-0.57,
                markUps:"121.8k"
             },
             {
                title:"XRPBTC",
                currency:0.00002345,
                precentage:0.43,
                markUps:"824.6k"
             }
        ]
},
    {
        title:"BCH",
        img:BitcoinIcon,
        insideData:[
            {
                title:"BCHAUD",
                currency:929.99,
                precentage:-0.05,
                markUps:"7.58"
             },
             {
                title:"BCHBTC",
                currency:0.01347,
                precentage:-3.37,
                markUps:"155.61"
             }
        ]
    },
    {
        title:"LTC",
        img:LtcIcon,
        insideData:[
            {
                title:"LTCAUD",
                currency:236.88,
                precentage:-3.63,
                markUps:"61.66"
             },
             {
                title:"LTCBTC",
                currency:0.003587,
                precentage:-2.45,
                markUps:"2.587K"
             }
        ]
    }
]


// const Dummydata = ()=>{
//     store.dispatch(dataActions.updateData(dummyData))
// return (
//     <p>Hello world</p>
// )
// }
// export default Dummydata;