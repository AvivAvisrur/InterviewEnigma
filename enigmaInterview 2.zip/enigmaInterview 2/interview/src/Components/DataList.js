import {useSelector} from "react-redux"
import * as React from 'react';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListSubheader from '@mui/material/ListSubheader';
import store from "../store/store";
import { dataActions } from "../store/data-slice";
import { dummyData } from "./dummyData";
import classes from "./DataList.module.css"
import iconXrp from "../icons/iconXRP.png"

const DataList = ()=>{
    store.dispatch(dataActions.updateData(dummyData))
    const data = useSelector(state=>state.data.data)
    return (
        <List
        sx={{
          width: '100%',
          maxWidth: 800,
          bgcolor: 'background.paper',
          position: 'relative',
          marginTop:"100px",
          overflow: 'auto',
          maxHeight: 600,
          backgroundColor:"transparent",
          color:"white",
          '& ul': { padding: 0 },
        }}
        subheader={<li />}
      >
        {data.map((item) => (
          <li key={`section-${item}`}>
            <ul>
              <ListSubheader sx = {{
                backgroundColor:'black',
                color:"white",
                fontSize : "1.5em"
                }}
                ><img src ={item.img} />{item.title}</ListSubheader>
                <hr/>
              {item.insideData.map((item) => (
                <div className = {classes.ListContainer}>
                <ListItem  key={item}>
                  <ListItemText primary={
                       <div className ={classes.spanContainer}>
                    <span className = {classes.title}>{item.title}</span>
                    <span >{item.currency}</span>
                    <span style = {item.precentage>0?{color:"green"}:{color:"red"}}>{item.precentage}% </span>
                    <span>{item.markUps}</span>
                    </div>
                  }  />
                </ListItem>
                </div>
                
              ))}
            </ul>
          </li>
        ))}
      </List>
    )
};
export default DataList;