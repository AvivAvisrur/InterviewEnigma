import { Fragment } from "react";
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import DataList from "./DataList";
import Button from '@mui/material/Button';
import ButtonGroup from '@mui/material/ButtonGroup';
import SearchBar from "material-ui-search-bar";



const Layout = ()=>{
    return (
        <Fragment>
        <Container maxWidth="sm" sx = {{width:"100%"}}>
      <Box sx={{ 
          backgroundColor:"black",
           height: '70vh' , 
           width:"70vh",
           display:"flex",
           justifyContent:"center",
           alignItems:"center",
           flexDirection:"column"}}>
           
           <header>
           <ButtonGroup variant="contained" aria-label="outlined primary button group" >
                <Button sx = {{width:"150px",height:"50px",marginRight:"20px"}}>XRP</Button>
                <Button sx = {{width:"150px",height:"50px",marginRight:"20px"}}>BCH</Button>
                <Button sx = {{width:"150px",height:"50px",marginRight:"20px"}}>LTC</Button>
                </ButtonGroup>
                <hr/>
                </header>
           
              
           <main>
    <DataList/>
    </main>
    </Box>
    </Container>
        </Fragment>
    )
};
export default Layout;